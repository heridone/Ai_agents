"""
Test suite for picoagents package.
"""
